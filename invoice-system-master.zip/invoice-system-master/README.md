<p align="center"><img src="http://mindscms.com/images/mindscms-logo.png" width="100"></p>
<h1 align="center">Minds CMS</h1>

## Invoice System
#### Youtube Course

Learn how to (CRUD) Create/Read/Update/Delete Invoices, plus learn hoe to print it, Export it to PDF file, and how to send an email with attached PDF Invoice file.

##### How to install. 

1- Download the project.

2- Update .env file & create Database.

3- Composer install.

4- install packages (npm install && npm run dev)

5- Enjoy :)
