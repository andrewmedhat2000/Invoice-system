<?php

return [

    'status' => true,


    'languages' => [

        'en' => ['en', 'en_US', false, 'English'],
        'ar' => ['ar', 'ar_SA', true, 'Arabic'],

    ]

];
