<?php

return [

    'new_invoice'           => 'New Invoice From Invoices System',
    'dear_user'             => 'Dear :name,',
    'greetings'             => 'Greetings,',
    'find_an_invoice'       => 'Please find the invoice attached.',
    'regards'               => 'Best Regards,',
    'seller_name'           => 'Sami Mansour Youtube Channel',
    'seller_phone'          => 'Tel: 9200000000',
    'seller_vat'            => 'VAT Num.: 123456789',
    'seller_address'        => 'Address: Jeddah, KSA',
    'footer'                => '' . date('Y') .', &copy; all copyright reserved.',

];
